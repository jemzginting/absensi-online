# Bootstrap 3 Date/Time Picker v4.17.47

We are in code freeze and this issue tracker is no longer actively monitored. I'll be closing PR that do not contribute emergency fixes and leaving some open as they are evaluated for migration into the new repo. I’ll be closing issues that do not meet minimum requirements or have been answered by the community. Issues that have been closed for longer than 30 days will be locked.

## [View the manual and demos](http://eonasdan.github.io/bootstrap-datetimepicker/)
